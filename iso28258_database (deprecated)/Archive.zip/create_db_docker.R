# The script shows how to ereate and explore dabasases and tables tables
# It is not embedded in the shiny app and it is only for its manual use for educational purpouses

library('RPostgres')
library('DBI')
library('dplyr')

# Create connection to postgres in localhost (RSTUDIO only)
dsn_database = "carsis"       # Specify the name of your Database
dsn_hostname = "localhost"    # Specify your hostname
dsn_port = 5432             # Specify your port number
dsn_uid = "gsp"          # Specify your username. e.g. "admin"
dsn_pwd = "gsp"   

# Connect to the database
  con <- dbConnect(RPostgres::Postgres(),
                   dbname = dsn_database,
                   host = dsn_hostname,
                   port = dsn_port,
                   user = dsn_uid,
                   password = dsn_pwd)

# List tables in the database
  dbListTables(con)
 
# List exiting databases
dbGetQuery(con, "SELECT datname FROM pg_database WHERE datistemplate = false;")

dbExecute(con, paste0("CREATE DATABASE ", "new_database"))

con <- dbConnect(RPostgres::Postgres(),
                 dbname = "new_database",
                 host = dsn_hostname,
                 port = dsn_port,
                 user = dsn_uid,
                 password = dsn_pwd)

dbExecute(con, paste0("DROP DATABASE ", "new_database"," WITH (FORCE);"))
dbGetQuery(con, "SELECT datname FROM pg_database WHERE datistemplate = false;")
dbDisconnect(con)
con <- dbConnect(RPostgres::Postgres(),
                 dbname = "postgres",
                 host = dsn_hostname,
                 port = dsn_port,
                 user = dsn_uid,
                 password = dsn_pwd)

