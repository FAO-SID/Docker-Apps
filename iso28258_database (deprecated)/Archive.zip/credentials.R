# # Postgresql credentials in Docker container
# database_name <- "postgres"
# host_name <- "postgis"
# port_number <- "5432"
# user_name <- "gsp"
# password_name <- "gsp"
# global_pass <- ""


# Postgresql credentials running from Rstudio
database_name <- "localhost"
host_name <- "postgis"
port_number <- "5432"
user_name <- "gsp"
password_name <- "gsp"
global_pass <- ""
